require 'test_helper'

class CoursesMenuTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
