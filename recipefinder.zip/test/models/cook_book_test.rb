require 'test_helper'

class CookBookTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
